# This is the side length of the triangle/hex
edge_length = 1